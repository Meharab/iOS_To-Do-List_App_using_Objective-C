//
//  AppDelegate.h
//  to do list
//
//  Created by Gadgets Planet on 11/3/18.
//  Copyright © 2018 mcclab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

